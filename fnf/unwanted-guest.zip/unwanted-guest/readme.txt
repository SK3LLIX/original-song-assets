Hey! If you're reading this, then you're probably
going to make a cover of my song, or maybe even
mod it into the game. Either way, please credit me,
..............
YouTube:
https://youtube.com/channel/UCxp8UpeTMU77is5sdNIuEQw
Discord:
skellix#7876
Discord Server:
https://discord.gg/yxhXD7YUr9
.....................................

Oh, and one last thing: the bpm of the song is 205.

                        - Skellix